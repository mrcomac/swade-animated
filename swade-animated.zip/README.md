# Note
There is no stable version yet. I don't have more than 4 hours per week to work on this. 
# swade-animated
Foundryvtt swade animated module is just for fun.

# Icons Credit
Author: J. W. Bjerk (eleazzaar) -- www.jwbjerk.com/art  -- find this and other open art at: http://opengameart.org
Website: https://www.wowhead.com/

# Sounds
Website: https://www.wowhead.com/

# Scripts
I didn't reinvent the wheel. I'm using [Sequencer](https://github.com/fantasycalendar/FoundryVTT-Sequencer) and [Token Magic](https://github.com/Feu-Secret/Tokenmagic). Also I'm using the macros created by [EskieMoh@](https://twitter.com/EskieMoh) and [SWADE Immersive Macros](https://github.com/SalieriC/SWADE-Immersive-Macros).

Licenses
- GNU GPL 2.0
- GNU GPL 3.0
- CC-BY 3.0
- CC-BY-SA 3.0
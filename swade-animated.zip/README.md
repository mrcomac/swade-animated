# swade-animated
Foundryvtt swade animated module


# Icons Credit
Author: J. W. Bjerk (eleazzaar) -- www.jwbjerk.com/art  -- find this and other open art at: http://opengameart.org

Licenses
- GNU GPL 2.0
- GNU GPL 3.0
- CC-BY 3.0
- CC-BY-SA 3.0